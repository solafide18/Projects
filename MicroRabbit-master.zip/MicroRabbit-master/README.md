# MicroRabbit
Microservice with RabbitMQ
